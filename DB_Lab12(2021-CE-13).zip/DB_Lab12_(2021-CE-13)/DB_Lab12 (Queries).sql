USE BikeStores;
--1:Select all categories:
SELECT * FROM production.categories;

--2:Select distinct brand names:
SELECT DISTINCT brand_name FROM production.brands;

--3:Select products with their category and brand names:
SELECT p.product_name, c.category_name, b.brand_name
FROM production.products p
INNER JOIN production.categories c ON p.category_id = c.category_id
INNER JOIN production.brands b ON p.brand_id = b.brand_id;

--4:Select active staff members and their associated store information:
SELECT s.*, st.store_name
FROM sales.staffs s
INNER JOIN sales.stores st ON s.store_id = st.store_id
WHERE s.active = 1;

--5:Select orders with customer information and order status:
SELECT o.order_id, c.first_name, c.last_name, o.order_status
FROM sales.orders o
INNER JOIN sales.customers c ON o.customer_id = c.customer_id;

--6:Select orders that are pending (order status = 1):
SELECT * FROM sales.orders WHERE order_status = 1;

--7:Select products with low stock (quantity less than 10):
SELECT * FROM production.stocks WHERE quantity < 10;

--8:Select the total list price of products in a specific category:
SELECT SUM(p.list_price) AS total_list_price
FROM production.products p
WHERE p.category_id = '1';

--9:Select customers with orders and their total order quantity:
SELECT c.first_name, c.last_name, COUNT(o.order_id) AS total_orders, SUM(oi.quantity) AS total_quantity
FROM sales.customers c
LEFT JOIN sales.orders o ON c.customer_id = o.customer_id
LEFT JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY c.first_name, c.last_name;

--10:SELECT * FROM sales.orders ORDER BY order_date DESC;
SELECT * FROM sales.orders ORDER BY order_date DESC;
